from pathlib import Path
from pydantic_settings import BaseSettings, SettingsConfigDict

BASE_DIR = Path(__file__).resolve().parent.parent

class Settings(BaseSettings):
    app_name: str = "ComicCraft"
    gemini_api_key: str = ""
    gemini_outline_model: str = "gemini-3.8-flash"
    gemini_story_model: str = "gemini-3.1-pro-preview"

    image_provider: str = "hf"  # hf | local_diffusers | placeholder
    hf_api_key: str = ""
    hf_image_model: str = "stable-diffusion-v1-5/stable-diffusion-v1-5"

    local_diffusers_model: str = "stable-diffusion-v1-5/stable-diffusion-v1-5"
    image_width: int = 512
    image_height: int = 512
    image_steps: int = 25

    output_dir: str = str(BASE_DIR / "static" / "panels")
    export_dir: str = str(BASE_DIR / "static" / "exports")

    max_prompt_length: int = 2000
    max_panels: int = 5

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=False,
        extra="ignore",
    )

settings = Settings()

Path(settings.output_dir).mkdir(parents=True, exist_ok=True)
Path(settings.export_dir).mkdir(parents=True, exist_ok=True)

from pathlib import Path
from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates

from app.routes import router
from app.config import settings

BASE_DIR = Path(__file__).resolve().parent.parent

app = FastAPI(
    title="ComicCraft",
    description="AI comic story creator using Gemini and Hugging Face Diffusers/Inference.",
    version="1.0.0",
)

app.mount("/static", StaticFiles(directory=str(BASE_DIR / "static")), name="static")
app.include_router(router)

@app.get("/health", tags=["system"])
async def health():
    return {"status": "ok", "app": settings.app_name}

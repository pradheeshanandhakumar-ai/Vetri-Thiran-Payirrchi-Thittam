import json
from google import genai
from google.genai import types

from app.config import settings
from app.schemas import StoryPanel

def _client():
    if not settings.gemini_api_key:
        raise RuntimeError("GEMINI_API_KEY is not configured.")
    return genai.Client(api_key=settings.gemini_api_key)

def generate_story(outline: list[dict], character_name: str, tone: str) -> list[dict]:
    client = _client()
    outline_json = json.dumps(outline, ensure_ascii=False)

    prompt = f"""
Expand this 5-panel comic outline into a polished comic script.

Character: {character_name}
Tone: {tone}

Outline:
{outline_json}

For every panel return:
- panel_number
- title
- scene_description
- image_prompt (preserve the original visual direction)
- caption: short ambient/cinematic caption
- narration: concise narration describing action/emotion
- dialogue: natural dialogue; empty string if no dialogue is needed

Keep continuity between panels. Do not invent extra panels.
Return JSON only.
"""
    response = client.models.generate_content(
        model=settings.gemini_story_model,
        contents=prompt,
        config=types.GenerateContentConfig(
            temperature=0.85,
            max_output_tokens=7000,
            response_mime_type="application/json",
            response_schema=list[StoryPanel],
        ),
    )
    data = json.loads(response.text)
    return [StoryPanel.model_validate(x).model_dump() for x in data]

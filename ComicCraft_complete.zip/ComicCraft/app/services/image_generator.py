from pathlib import Path
import re
import uuid

from PIL import Image, ImageDraw, ImageFont

from app.config import settings

_pipeline = None

def _safe_name(text: str) -> str:
    value = re.sub(r"[^a-zA-Z0-9_-]+", "_", text).strip("_")
    return value[:60] or "panel"

def _placeholder(prompt: str, output_path: Path) -> None:
    img = Image.new("RGB", (settings.image_width, settings.image_height), "white")
    draw = ImageDraw.Draw(img)
    title = "ComicCraft"
    draw.rectangle((8, 8, settings.image_width-8, settings.image_height-8), outline="black", width=6)
    draw.text((30, 35), title, fill="black")
    words = prompt[:220]
    draw.text((30, 90), words, fill="black", spacing=8)
    img.save(output_path)

def _generate_hf(prompt: str, output_path: Path) -> None:
    if not settings.hf_api_key:
        raise RuntimeError("HF_API_KEY is not configured for the Hugging Face image provider.")
    from huggingface_hub import InferenceClient
    client = InferenceClient(provider="hf-inference", api_key=settings.hf_api_key)
    image = client.text_to_image(
        prompt,
        model=settings.hf_image_model,
    )
    image.save(output_path)

def _generate_local(prompt: str, output_path: Path) -> None:
    global _pipeline
    import torch
    from diffusers import StableDiffusionPipeline

    if _pipeline is None:
        dtype = torch.float16 if torch.cuda.is_available() else torch.float32
        _pipeline = StableDiffusionPipeline.from_pretrained(
            settings.local_diffusers_model,
            torch_dtype=dtype,
            use_safetensors=True,
        )
        _pipeline = _pipeline.to("cuda" if torch.cuda.is_available() else "cpu")

    result = _pipeline(
        prompt=prompt,
        negative_prompt="blurry, low quality, distorted, text, watermark",
        width=settings.image_width,
        height=settings.image_height,
        num_inference_steps=settings.image_steps,
    )
    result.images[0].save(output_path)

def generate_image(prompt: str, panel_number: int, title: str) -> str:
    filename = f"{panel_number:02d}_{_safe_name(title)}_{uuid.uuid4().hex[:8]}.png"
    path = Path(settings.output_dir) / filename
    provider = settings.image_provider.lower()

    if provider == "hf":
        _generate_hf(prompt, path)
    elif provider == "local_diffusers":
        _generate_local(prompt, path)
    elif provider == "placeholder":
        _placeholder(prompt, path)
    else:
        raise RuntimeError(f"Unknown IMAGE_PROVIDER: {provider}")

    return f"/static/panels/{filename}"

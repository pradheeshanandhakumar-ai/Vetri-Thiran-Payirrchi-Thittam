from pathlib import Path
from datetime import datetime
import re

from fpdf import FPDF
from PIL import Image

from app.config import settings

def _local_image_path(url: str) -> Path:
    return Path(settings.output_dir) / Path(url).name

def save_pdf(layout: list[dict], title: str) -> str:
    filename = f"comic_{datetime.now().strftime('%Y%m%d_%H%M%S')}.pdf"
    output = Path(settings.export_dir) / filename

    pdf = FPDF(orientation="P", unit="mm", format="A4")
    pdf.set_auto_page_break(auto=True, margin=15)

    for panel in layout:
        pdf.add_page()
        pdf.set_font("Helvetica", "B", 18)
        pdf.multi_cell(0, 10, f"Panel {panel['panel_number']}: {panel['title']}")
        pdf.ln(2)

        image_path = _local_image_path(panel["image_path"])
        if image_path.exists():
            with Image.open(image_path) as img:
                w, h = img.size
            max_w, max_h = 180, 115
            ratio = min(max_w / w, max_h / h)
            iw, ih = w * ratio, h * ratio
            x = (210 - iw) / 2
            pdf.image(str(image_path), x=x, y=pdf.get_y(), w=iw, h=ih)
            pdf.ln(ih + 5)

        pdf.set_font("Helvetica", "I", 10)
        pdf.multi_cell(0, 6, panel["scene_description"])
        pdf.ln(2)

        pdf.set_font("Helvetica", "B", 11)
        pdf.multi_cell(0, 6, "Caption")
        pdf.set_font("Helvetica", "", 11)
        pdf.multi_cell(0, 6, panel["caption"])
        pdf.ln(2)

        pdf.set_font("Helvetica", "B", 11)
        pdf.multi_cell(0, 6, "Narration")
        pdf.set_font("Helvetica", "", 11)
        pdf.multi_cell(0, 6, panel["narration"])

        if panel.get("dialogue"):
            pdf.ln(2)
            pdf.set_font("Helvetica", "B", 11)
            pdf.multi_cell(0, 6, "Dialogue")
            pdf.set_font("Helvetica", "", 11)
            pdf.multi_cell(0, 6, panel["dialogue"])

    pdf.output(str(output))
    return f"/static/exports/{filename}"

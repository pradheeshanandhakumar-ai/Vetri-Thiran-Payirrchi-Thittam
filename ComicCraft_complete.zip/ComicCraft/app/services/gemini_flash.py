import json
from google import genai
from google.genai import types

from app.config import settings
from app.schemas import Panel

def _client():
    if not settings.gemini_api_key:
        raise RuntimeError("GEMINI_API_KEY is not configured.")
    return genai.Client(api_key=settings.gemini_api_key)

def generate_outline(
    story_prompt: str,
    character_name: str,
    setting: str,
    tone: str,
    art_style: str,
) -> list[dict]:
    client = _client()
    prompt = f"""
Create a cohesive 5-panel comic outline.

User story idea: {story_prompt}
Main character: {character_name}
Setting: {setting}
Tone: {tone}
Art style: {art_style}

Requirements:
- Exactly 5 panels.
- Keep the same protagonist and visual identity throughout.
- Give each panel a short title.
- Give a concise scene description.
- Give an image-generation prompt that describes composition, characters,
  environment, lighting, camera angle, action and the requested art style.
- Do not put dialogue text inside the image prompt.
- Return JSON only.
"""
    schema = list[Panel]
    response = client.models.generate_content(
        model=settings.gemini_outline_model,
        contents=prompt,
        config=types.GenerateContentConfig(
            temperature=0.9,
            max_output_tokens=5000,
            response_mime_type="application/json",
            response_schema=schema,
        ),
    )
    data = json.loads(response.text)
    return [Panel.model_validate(x).model_dump() for x in data]

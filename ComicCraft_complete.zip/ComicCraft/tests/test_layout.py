from app.services.layout_builder import build_comic_layout

def test_layout_pairs_panels_and_images():
    panels = [
        {
            "panel_number": 1,
            "title": "Start",
            "scene_description": "A forest",
            "image_prompt": "forest",
            "caption": "Morning",
            "narration": "A journey begins",
            "dialogue": "",
        }
    ]
    result = build_comic_layout(panels, ["/static/panels/one.png"])
    assert result[0]["image_path"] == "/static/panels/one.png"
    assert result[0]["panel_number"] == 1

const form = document.getElementById("comic-form");
const button = document.getElementById("generate-btn");
const status = document.getElementById("status");

if (form) {
  form.addEventListener("submit", () => {
    button.disabled = true;
    button.textContent = "Creating...";
    status.textContent = "Generating outline, story and illustrations. This can take a while.";
  });
}

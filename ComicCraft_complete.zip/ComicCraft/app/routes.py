from fastapi import APIRouter, Form, HTTPException, Request
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates

from app.schemas import PromptRequest
from app.services.gemini_flash import generate_outline
from app.services.gemini_pro import generate_story
from app.services.image_generator import generate_image
from app.services.layout_builder import build_comic_layout
from app.services.exporters import save_pdf

templates = Jinja2Templates(directory="templates")
router = APIRouter()

def _validate_prompt(request: PromptRequest):
    if len(request.story_prompt) > 2000:
        raise HTTPException(status_code=422, detail="Story prompt is too long.")

def create_comic(data: PromptRequest):
    outline = generate_outline(
        data.story_prompt, data.character_name, data.setting,
        data.tone, data.art_style
    )
    story = generate_story(outline, data.character_name, data.tone)

    image_paths = []
    for panel in story:
        visual_prompt = (
            f"{panel['image_prompt']}. "
            f"Consistent comic panel, clean composition, no speech bubbles, no text."
        )
        image_paths.append(
            generate_image(visual_prompt, panel["panel_number"], panel["title"])
        )

    layout = build_comic_layout(story, image_paths)
    pdf_url = save_pdf(layout, story[0]["title"] if story else "ComicCraft")
    return layout, pdf_url

@router.get("/", response_class=HTMLResponse)
async def home(request: Request):
    return templates.TemplateResponse(
        request=request,
        name="index.html",
        context={}
    )

@router.post("/generate", response_class=HTMLResponse)
async def generate(
    request: Request,
    story_prompt: str = Form(...),
    character_name: str = Form(...),
    setting: str = Form(...),
    tone: str = Form(...),
    art_style: str = Form(...),
):
    try:
        data = PromptRequest(
            story_prompt=story_prompt,
            character_name=character_name,
            setting=setting,
            tone=tone,
            art_style=art_style,
        )
        _validate_prompt(data)
        layout, pdf_url = create_comic(data)
        return templates.TemplateResponse(
            request=request,
            name="comic_preview.html",
            context={
                "layout": layout,
                "pdf_url": pdf_url,
                "title": f"{data.character_name}'s Comic",
            },
        )
    except HTTPException:
        raise
    except Exception as exc:
        return templates.TemplateResponse(
            request=request,
            name="index.html",
            context={"error": str(exc)},
            status_code=500,
        )

@router.post("/generate-comic/json")
async def generate_json(data: PromptRequest):
    _validate_prompt(data)
    try:
        layout, pdf_url = create_comic(data)
        return {
            "title": f"{data.character_name}'s Comic",
            "panels": layout,
            "pdf_url": pdf_url,
        }
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc)) from exc

@router.get("/test-image", response_class=HTMLResponse)
async def test_image(prompt: str = "A brave fox exploring an enchanted forest, comic book art"):
    try:
        image_url = generate_image(prompt, 1, "image-test")
        return f'<html><body style="font-family:sans-serif"><h1>Image test</h1><img src="{image_url}" style="max-width:700px"><p>{prompt}</p></body></html>'
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc)) from exc

@router.get("/export-success", response_class=HTMLResponse)
async def export_success(request: Request, pdf_url: str = ""):
    return templates.TemplateResponse(
        request=request,
        name="export_success.html",
        context={"pdf_url": pdf_url},
    )

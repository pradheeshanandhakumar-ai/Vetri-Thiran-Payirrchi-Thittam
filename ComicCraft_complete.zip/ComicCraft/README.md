# ComicCraft — AI Comic Story Creator

ComicCraft is a FastAPI web application that turns a user prompt into a five-panel comic. It follows the architecture described in the supplied project document: FastAPI + Jinja2 frontend, Gemini for structured outline/story generation, an image-generation layer, panel layout assembly, and PDF export.

## Architecture

Browser -> FastAPI routes -> Gemini outline -> Gemini story -> image provider -> layout builder -> PDF exporter -> Jinja2 preview

### Why the implementation differs slightly from the original document

The supplied document names the older `google-generativeai` Python package and Gemini 1.5 model IDs. The implementation uses Google's current `google-genai` SDK and configurable model IDs instead, because the older model/package choices can be retired over time. Change the values in `.env` if your API account exposes different models.

The image layer supports:
1. `hf` — Hugging Face hosted inference (recommended for a normal laptop).
2. `local_diffusers` — local Stable Diffusion with Diffusers/PyTorch (requires suitable hardware and more setup).
3. `placeholder` — no external image API; useful for testing the whole web/PDF pipeline.

## Folder structure

```text
ComicCraft/
├── app/
│   ├── __init__.py
│   ├── main.py
│   ├── config.py
│   ├── routes.py
│   ├── schemas.py
│   └── services/
│       ├── __init__.py
│       ├── gemini_flash.py
│       ├── gemini_pro.py
│       ├── image_generator.py
│       ├── layout_builder.py
│       └── exporters.py
├── templates/
│   ├── index.html
│   ├── comic_preview.html
│   └── export_success.html
├── static/
│   ├── css/styles.css
│   ├── js/app.js
│   ├── panels/
│   └── exports/
├── tests/
│   ├── test_app.py
│   └── test_layout.py
├── .env.example
├── .gitignore
├── requirements.txt
├── requirements-local-diffusers.txt
└── README.md
```

## VS Code setup — Windows

### 1. Install prerequisites

Install Python 3.11+ and VS Code.

Open the ComicCraft folder in VS Code.

### 2. Create a virtual environment

PowerShell:

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
```

If PowerShell blocks activation, use Command Prompt:

```cmd
.venv\Scripts\activate
```

### 3. Install dependencies

```bash
python -m pip install --upgrade pip
pip install -r requirements.txt
```

### 4. Create `.env`

Copy `.env.example` to `.env` and add your keys:

```env
GEMINI_API_KEY=...
HF_API_KEY=...
IMAGE_PROVIDER=hf
```

Do not commit `.env` to Git.

### 5. Run

```bash
uvicorn app.main:app --reload
```

Open:

- http://127.0.0.1:8000
- http://127.0.0.1:8000/docs
- http://127.0.0.1:8000/health

## Testing without AI generation

Set:

```env
IMAGE_PROVIDER=placeholder
```

Then run:

```bash
pytest -q
```

This tests the FastAPI app and layout logic without downloading a diffusion model.

## Testing image generation

With Hugging Face:

```env
IMAGE_PROVIDER=hf
HF_API_KEY=your_key
```

Then open:

```text
http://127.0.0.1:8000/test-image?prompt=A%20brave%20fox%20in%20an%20enchanted%20forest
```

## Local Stable Diffusion option

If you have an appropriate NVIDIA GPU and enough VRAM:

```bash
pip install -r requirements-local-diffusers.txt
```

Then set:

```env
IMAGE_PROVIDER=local_diffusers
LOCAL_DIFFUSERS_MODEL=stable-diffusion-v1-5/stable-diffusion-v1-5
```

The first generation downloads model files and can take significant time and disk space. CPU generation is possible but can be extremely slow.

## API example

POST `/generate-comic/json`:

```json
{
  "story_prompt": "A brave fox explores an enchanted forest.",
  "character_name": "Luna",
  "setting": "Enchanted forest",
  "tone": "Adventurous",
  "art_style": "Comic book"
}
```

The response contains the generated panels and `pdf_url`.

## Common problems

### `GEMINI_API_KEY is not configured`
Make sure `.env` exists in the project root and contains a valid key. Restart Uvicorn after changing environment variables.

### Gemini model not available
Model availability changes. Set `GEMINI_OUTLINE_MODEL` and `GEMINI_STORY_MODEL` in `.env` to models available to your account.

### Hugging Face image request fails
Check `HF_API_KEY`, your account/model access, and the configured model. You can switch temporarily to `IMAGE_PROVIDER=placeholder` to test the rest of the application.

### PDF contains missing images
Make sure image generation completed successfully and that `static/panels` is writable.

## Production notes

This is a local/project implementation, not a production-hardened SaaS. Before public deployment add authentication, rate limiting, job queues/background workers, persistent storage, request IDs/logging, secret management, cleanup of generated files, content moderation, and stronger error handling.
